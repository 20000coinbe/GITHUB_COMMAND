def add(a,b):
    return a + b

def sub(a,b):
    return a - b

def mutifly(a, b):
    return a * b

def divide(a , b):
    return a / b
